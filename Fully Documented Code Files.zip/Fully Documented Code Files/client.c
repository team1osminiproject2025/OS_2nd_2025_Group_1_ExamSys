/*
 * ExamSys - Student Client
 * ------------------------
 * Connects to ExamSys server, authenticates student,
 * receives exam questions, enforces time limits,
 * and submits detailed results back to server.
 *
 * Author: [Your Name]
 * Date:   [Date]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <ctype.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <errno.h>

// ----------------------- Configuration -----------------------
#define MAX_LINE 512                 // Max buffer length for text fields
#define NUM_EXAM_QUESTIONS 5         // Default number of questions to display
#define MIN_ANSWER_TIME 5            // Minimum plausible time per question
#define SERVER_IP "127.0.0.1"       // Default server address (loopback)
#define SERVER_PORT 8080             // Server TCP port for connections

// ----------------------- Global Flags ------------------------
volatile int examTimeUp = 0;         // Set when overall exam timer expires
int overallExamTime = 300;           // Total exam duration in seconds

// ----------------------- Data Structures ---------------------

/**
 * Question:
 * Represents a single MCQ received from server
 */
typedef struct {
    char question[MAX_LINE];
    char optionA[MAX_LINE];
    char optionB[MAX_LINE];
    char optionC[MAX_LINE];
    char optionD[MAX_LINE];
    char correct;                    // Correct choice: 'A'-'D'
    int difficulty;                  // 1=Easy,2=Medium,3=Hard
} Question;

/**
 * ExamResult:
 * Holds per-student results to send back
 */
typedef struct {
    char roll[MAX_LINE];             // Student roll number
    char name[MAX_LINE];             // Student name
    int responseTimes[NUM_EXAM_QUESTIONS]; // Time taken per question
    int totalTime;                   // Sum of responseTimes
    int correctAnswers;              // Number of correct responses
    int totalQuestions;              // Attempted count
    int flagged;                     // Suspiciously fast answers flag
} ExamResult;

// ----------------------- Utility Functions ------------------

/**
 * clear_input_buffer(): Flush stdin until newline or EOF
 */
void clear_input_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

/**
 * getPassword(): Read password without echo
 *  - Disables terminal echo, reads line, restores settings
 */
void getPassword(char *password, int size) {
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);  
    newt = oldt;
    newt.c_lflag &= ~(ECHO);         // Turn off echo
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    if (fgets(password, size, stdin) != NULL) {
        password[strcspn(password, "\n")] = '\0';
    }

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt); // Restore terminal
    printf("\n");
}

/**
 * get_input_with_timeout(): Wait for user input with timeout
 * @buf: destination buffer
 * @buf_size: max chars
 * @timeout_seconds: seconds to wait
 * Returns 1 if input was received, 0 on timeout or error
 */
int get_input_with_timeout(char *buf, int buf_size, int timeout_seconds) {
    fd_set set;
    struct timeval timeout;
    FD_ZERO(&set);
    FD_SET(STDIN_FILENO, &set);
    timeout.tv_sec = timeout_seconds;
    timeout.tv_usec = 0;

    int rv = select(STDIN_FILENO + 1, &set, NULL, NULL, &timeout);
    if (rv == -1) {
        perror("📛 select");
        return 0;
    } else if (rv == 0) {
        // Timeout occurred
        return 0;
    } else {
        // Data available
        if (fgets(buf, buf_size, stdin) == NULL) return 0;
        buf[strcspn(buf, "\n")] = '\0';
        return 1;
    }
}

/**
 * overall_timer(): Thread function to enforce total exam duration
 * Sleeps for overallExamTime, then flags examTimeUp
 */
void *overall_timer(void *arg) {
    sleep(overallExamTime);
    examTimeUp = 1;
    printf("\n⏰ *** Overall exam time is up! The exam will now end. ***\n");
    pthread_exit(NULL);
}
void conduct_exam() {
    unordered_map<int, string> client_ips;
    unordered_map<int, string> student_ids;
    map<int, int> id_to_port;

    // Prepare pollfd structs for all client sockets
    vector<struct pollfd> pfds;
    for (int fd : client_sockets) {
        struct pollfd pfd;
        pfd.fd = fd;
        pfd.events = POLLIN;
        pfds.push_back(pfd);
    }

    // Send question paper to each student
    for (int fd : client_sockets) {
        stringstream ss;
        ss << questions.size() << "\n";
        for (const auto& q : questions) {
            ss << q.text << "\n";
            for (const auto& opt : q.options) ss << opt << "\n";
        }
        string questions_data = ss.str();
        send(fd, questions_data.c_str(), questions_data.size(), 0);
    }

    auto start_time = chrono::steady_clock::now();
    auto end_time = start_time + chrono::minutes(1);  // 1-minute exam duration

    int num_students = client_sockets.size();
    int num_responses = 0;

    while (chrono::steady_clock::now() < end_time && num_responses < num_students) {
        int ret = poll(pfds.data(), pfds.size(), 1000);  // wait 1s
        if (ret > 0) {
            for (auto& pfd : pfds) {
                if (pfd.revents & POLLIN) {
                    char buffer[4096] = {0};
                    int valread = recv(pfd.fd, buffer, sizeof(buffer), 0);
                    if (valread > 0) {
                        stringstream ss(buffer);
                        string student_id;
                        getline(ss, student_id);

                        vector<int> answers;
                        string line;
                        while (getline(ss, line)) {
                            if (!line.empty()) {
                                answers.push_back(stoi(line));
                            }
                        }

                        student_answers[student_id] = answers;

                        sockaddr_in addr;
                        socklen_t len = sizeof(addr);
                        getpeername(pfd.fd, (struct sockaddr*)&addr, &len);

                        student_ips[student_id] = inet_ntoa(addr.sin_addr);
                        id_to_port[student_id] = ntohs(addr.sin_port);
                        student_ids[pfd.fd] = student_id;

                        ++num_responses;
                    }
                }
            }
        }
    }

    // Mark unanswered students with -1
    for (int fd : client_sockets) {
        if (!student_ids.count(fd)) {
            sockaddr_in addr;
            socklen_t len = sizeof(addr);
            getpeername(fd, (struct sockaddr*)&addr, &len);

            string ip = inet_ntoa(addr.sin_addr);
            int port = ntohs(addr.sin_port);
            stringstream ss;
            ss << ip << ":" << port;
            string fallback_id = ss.str();

            student_ips[fallback_id] = ip;
            id_to_port[fallback_id] = port;

            vector<int> default_answers(questions.size(), -1);
            student_answers[fallback_id] = default_answers;
        }
    }

    // Calculate and log scores
    ofstream log_file("exam_results.log");
    for (const auto& [student_id, answers] : student_answers) {
        int score = 0;
        for (size_t i = 0; i < questions.size(); ++i) {
            if (i < answers.size() && answers[i] == questions[i].correct_option) {
                ++score;
            }
        }

        log_file << "Student ID: " << student_id << "\n";
        log_file << "IP Address: " << student_ips[student_id] << "\n";
        log_file << "Port: " << id_to_port[student_id] << "\n";
        log_file << "Score: " << score << "/" << questions.size() << "\n\n";
    }

    log_file.close();
    cout << "Exam results logged in 'exam_results.log'" << endl;
}
int main() {
    load_questions("questions.txt");
    cout << "Loaded " << questions.size() << " questions from file." << endl;

    int server_fd;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);

    // Create socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        cerr << "Socket creation error\n";
        exit(EXIT_FAILURE);
    }

    // Allow reuse of address and port
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));

    // Bind socket to port
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;  // accept connections from any IP
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        cerr << "Bind failed\n";
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, MAX_CLIENTS) < 0) {
        cerr << "Listen failed\n";
        exit(EXIT_FAILURE);
    }

    cout << "Server listening on port " << PORT << "..." << endl;

    // Accept client connections
    while (client_sockets.size() < MAX_CLIENTS) {
        int new_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
        if (new_socket < 0) {
            cerr << "Accept failed\n";
            continue;
        }

        client_sockets.push_back(new_socket);
        cout << "New client connected: " << inet_ntoa(address.sin_addr) << ":" << ntohs(address.sin_port) << endl;
    }

    cout << "All clients connected. Starting exam..." << endl;
    conduct_exam();

    // Close sockets after exam
    for (int fd : client_sockets) {
        close(fd);
    }

    close(server_fd);
    return 0;
}
