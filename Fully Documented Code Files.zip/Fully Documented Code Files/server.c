/*
 * ExamSys - Instructor Server
 * ---------------------------
 * A multi-threaded TCP server for conducting timed exams remotely.
 * Instructors can configure rules, add questions, and start exams.
 * Students connect as clients to receive questions and submit answers.
 */

 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <pthread.h>
 #include <unistd.h>
 #include <ctype.h>
 #include <fcntl.h>
 #include <errno.h>
 #include <termios.h>
 #include <sys/socket.h>
 #include <netinet/in.h>
 #include <arpa/inet.h>
 #include <time.h>
 
 // ----------------------- Configuration -----------------------
 #define MAX_QUESTIONS 200            // Maximum questions in question bank
 #define MAX_LINE 512                 // Max length of any input line
 #define MAX_STUDENTS 100             // Max concurrent students
 #define STUDENT_FILE "student_dtls.txt"
 #define INSTRUCTOR_FILE "instructor_dtls.txt"
 #define QUESTION_FILE "questions_with_difficulty.txt"
 #define RESULT_FILE "results.txt"
 #define RULES_FILE "rules.txt"
 #define NUM_EXAM_QUESTIONS 5         // Number of questions per exam
 #define SERVER_PORT 8080             // TCP port for server
 
 // Default rule values
 int answerTimeout = 30;              // seconds allowed per question
 float marksForCorrectAnswer = 1.0f;  // marks awarded for correct answer
 float marksDeductedForWrongAnswer = 0.25f; // marks penalized for wrong answer
 
 // Exam control flags
 volatile int examStarted = 0;
 pthread_mutex_t exam_mutex = PTHREAD_MUTEX_INITIALIZER;
 pthread_cond_t exam_cond   = PTHREAD_COND_INITIALIZER;
 
 // ----------------------- Data Structures -----------------------
 
 // Student login details stored in plain text for simplicity
 typedef struct {
     char name[MAX_LINE];
     char roll[MAX_LINE];
     char reg_no[MAX_LINE];
     char password[MAX_LINE];
 } Student;
 
 // Instructor login details
 typedef struct {
     char name[MAX_LINE];
     char instructor_id[MAX_LINE];
     char password[MAX_LINE];
 } Instructor;
 
 // Structure representing a single MCQ question
 typedef struct {
     char question[MAX_LINE];
     char optionA[MAX_LINE];
     char optionB[MAX_LINE];
     char optionC[MAX_LINE];
     char optionD[MAX_LINE];
     char correct;     // 'A', 'B', 'C', or 'D'
     char padding1[3]; // pad to 4-byte alignment
     int difficulty;   // 1=Easy, 2=Medium, 3=Hard
 } Question;
 
 // Dashboard data per student after exam
 typedef struct {
     char roll[MAX_LINE];
     char name[MAX_LINE];
     int responseTimes[NUM_EXAM_QUESTIONS]; // time taken for each question
     int totalTime;         // total time spent
     int correctAnswers;    // count of correct
     int totalQuestions;    // should equal NUM_EXAM_QUESTIONS
     int rank;              // assigned after ranking
     int flagged;           // flags suspicious if too fast
 } DashboardStudent;
 
 // Client connection tracking
 typedef struct {
     int sock;              // socket descriptor
     char roll[MAX_LINE];   // student roll number
 } Client;
 
 // ----------------------- Global Variables -----------------------
 DashboardStudent dashboardStudents[MAX_STUDENTS];
 int studentCount = 0;
 
 Question questions[MAX_QUESTIONS];
 int totalQuestions = 0;
 
 Client clients[MAX_STUDENTS];
 int clientCount = 0;
 pthread_mutex_t clients_mutex = PTHREAD_MUTEX_INITIALIZER;
 
 // ----------------------- Utility Functions -----------------------
 
 /**
  * clear_input_buffer: flushes stdin until newline or EOF
  */
 void clear_input_buffer() {
     int c;
     while ((c = getchar()) != '\n' && c != EOF);
 }
 
 /**
  * getPassword: reads password from terminal without echoing
  * @password: buffer to store input
  * @size: size of buffer
  */
 void getPassword(char *password, int size) {
     struct termios oldt, newt;
     tcgetattr(STDIN_FILENO, &oldt);          // save current terminal settings
     newt = oldt;
     newt.c_lflag &= ~(ECHO);                // disable echo
     tcsetattr(STDIN_FILENO, TCSANOW, &newt); // apply no-echo
 
     if (fgets(password, size, stdin) != NULL) {
         password[strcspn(password, "\n")] = '\0';
     }
 
     tcsetattr(STDIN_FILENO, TCSANOW, &oldt); // restore terminal
     printf("\n");
 }
 
 /**
  * log_hexdump: prints raw bytes of data buffer in hex, 16 bytes per line
  * @data: pointer to buffer
  * @size: number of bytes
  */
 void log_hexdump(const void *data, size_t size) {
     const unsigned char *buf = (const unsigned char *)data;
     for (size_t i = 0; i < size; i++) {
         printf("%02x ", buf[i]);
         if ((i + 1) % 16 == 0) printf("\n");
     }
     printf("\n");
 }
 
 /**
  * trim: removes leading/trailing whitespace and newline from string
  */
 void trim(char *s) {
     // remove trailing newline/whitespace
     s[strcspn(s, "\n")] = '\0';
     while (isspace((unsigned char)*s)) s++; // remove leading spaces
     // strip trailing spaces
     char *end = s + strlen(s) - 1;
     while (end > s && isspace((unsigned char)*end)) {
         *end = '\0';
         end--;
     }
 }
 
 /**
  * read_nonempty_line: reads next non-blank line from file
  * @fp: file pointer
  * @buffer: char array to fill
  * @size: buffer size
  * returns 1 if success, 0 on EOF
  */
 int read_nonempty_line(FILE *fp, char *buffer, int size) {
     while (fgets(buffer, size, fp)) {
         buffer[strcspn(buffer, "\n")] = '\0';
         // skip blank lines
         char temp[MAX_LINE];
         strcpy(temp, buffer);
         char *start = temp;
         while (*start && isspace((unsigned char)*start)) start++;
         if (strlen(start) > 0) {
             strcpy(buffer, start);
             return 1;
         }
     }
     return 0;
 }


/**
 * load_rules: Reads or creates rules file to set time limits and marking scheme
 */
void load_rules() {
    FILE *fp = fopen(RULES_FILE, "r");
    // reset to defaults before reading
    answerTimeout = 30;
    marksForCorrectAnswer = 1.0f;
    marksDeductedForWrongAnswer = 0.25f;

    if (fp == NULL) {
        printf("📛 Rules file not found, creating with defaults\n");
        fp = fopen(RULES_FILE, "w");
        if (!fp) { perror("📛 Error creating rules file"); return; }
        fprintf(fp,
            "Time limit per question: %d\n"
            "Marks awarded for correct answer: %.2f\n"
            "Marks deducted for incorrect answer: %.2f\n",
            answerTimeout, marksForCorrectAnswer, marksDeductedForWrongAnswer
        );
        fclose(fp);
    } else {
        char buffer[MAX_LINE];
        // parse each rule line, fallback to defaults on error
        if (fgets(buffer, MAX_LINE, fp)) {
            sscanf(buffer, "Time limit per question: %d", &answerTimeout);
        }
        if (fgets(buffer, MAX_LINE, fp)) {
            sscanf(buffer, "Marks awarded for correct answer: %f", &marksForCorrectAnswer);
        }
        if (fgets(buffer, MAX_LINE, fp)) {
            sscanf(buffer, "Marks deducted for incorrect answer: %f", &marksDeductedForWrongAnswer);
        }
        fclose(fp);
    }
    printf("📜 Loaded rules: Timeout=%d, +Correct=%.2f, -Wrong=%.2f\n",
           answerTimeout, marksForCorrectAnswer, marksDeductedForWrongAnswer);
}

/**
 * load_questions: Reads question bank file into memory,
 *                 creates defaults if missing or insufficient
 */
void load_questions() {
    FILE *fp = fopen(QUESTION_FILE, "r");
    if (!fp) {
        printf("📛 Questions file not found, creating default question\n");
        fp = fopen(QUESTION_FILE, "w");
        fprintf(fp,
            "What is the default question?\n"
            "Option A\nOption B\nOption C\nOption D\n"
            "A\n1\n"
        );
        fclose(fp);
        fp = fopen(QUESTION_FILE, "r");
    }

    char line[MAX_LINE];
    totalQuestions = 0;
    // iterate until EOF or max
    while (totalQuestions < MAX_QUESTIONS && read_nonempty_line(fp, line, MAX_LINE)) {
        Question *q = &questions[totalQuestions];
        strncpy(q->question, line, MAX_LINE);
        read_nonempty_line(fp, line, MAX_LINE); strncpy(q->optionA, line, MAX_LINE);
        read_nonempty_line(fp, line, MAX_LINE); strncpy(q->optionB, line, MAX_LINE);
        read_nonempty_line(fp, line, MAX_LINE); strncpy(q->optionC, line, MAX_LINE);
        read_nonempty_line(fp, line, MAX_LINE); strncpy(q->optionD, line, MAX_LINE);
        read_nonempty_line(fp, line, MAX_LINE); q->correct = toupper(line[0]);
        read_nonempty_line(fp, line, MAX_LINE); q->difficulty = atoi(line);
        // validate question
        if (strchr("ABCD", q->correct) && q->difficulty>=1 && q->difficulty<=3) {
            totalQuestions++;
        }
    }
    fclose(fp);

    // ensure minimum question count
    while (totalQuestions < NUM_EXAM_QUESTIONS) {
        Question *q = &questions[totalQuestions++];
        strcpy(q->question, "What is the default question?");
        strcpy(q->optionA, "Option A"); strcpy(q->optionB, "Option B");
        strcpy(q->optionC, "Option C"); strcpy(q->optionD, "Option D");
        q->correct = 'A'; q->difficulty = 1;
    }
    printf("📚 Total loaded questions: %d\n", totalQuestions);
}

/**
 * verify_student: checks roll & password against student file
 * returns 1 on success and outputs name & reg_no
 */
int verify_student(const char *roll, const char *pass, char *name, char *reg_no) {
    FILE *fp = fopen(STUDENT_FILE, "r");
    if (!fp) { perror("📛 Error opening student file"); return 0; }
    char fName[MAX_LINE], fRoll[MAX_LINE], fReg[MAX_LINE], fPass[MAX_LINE];
    int valid = 0;
    while (fscanf(fp, "%s %s %s %s", fName, fRoll, fReg, fPass)==4) {
        if (!strcmp(fRoll, roll) && !strcmp(fPass, pass)) {
            strcpy(name, fName); strcpy(reg_no, fReg); valid=1; break;
        }
    }
    fclose(fp);
    return valid;
}

/**
 * verify_instructor: similar to verify_student for instructor file
 */
int verify_instructor(const char *id, const char *pass, char *name) {
    FILE *fp = fopen(INSTRUCTOR_FILE, "r");
    if (!fp) { perror("📛 Error opening instructor file"); return 0; }
    char fName[MAX_LINE], fID[MAX_LINE], fPass[MAX_LINE];
    int valid = 0;
    while (fscanf(fp, "%s %s %s", fName, fID, fPass)==3) {
        if (!strcmp(fID, id) && !strcmp(fPass, pass)) { strcpy(name, fName); valid=1; break; }
    }
    fclose(fp);
    return valid;
}

/**
 * append_result: atomically appends a student's dashboard result to disk
 */
void append_result(DashboardStudent *s) {
    FILE *fp = fopen(RESULT_FILE, "a");
    if (!fp) { perror("📛 Error opening results file"); return; }
    int fd = fileno(fp);
    struct flock lock = {0}; lock.l_type = F_WRLCK;
    fcntl(fd, F_SETLKW, &lock);
    // write pipe-separated values + response times
    fprintf(fp, "%s|%s|%d|%d|%d|%d|",
        s->roll, s->name, s->correctAnswers,
        s->totalQuestions, s->flagged, s->totalTime);
    for (int i=0; i<s->totalQuestions; ++i) fprintf(fp, "%d,", s->responseTimes[i]);
    fprintf(fp, "\n");
    // release lock
    lock.l_type = F_UNLCK; fcntl(fd, F_SETLK, &lock);
    fclose(fp);
}

/**
 * loadDashboardData: loads all past exam results into memory
 */
void loadDashboardData() {
    FILE *fp = fopen(RESULT_FILE, "r");
    if (!fp) return;
    char line[MAX_LINE]; studentCount=0;
    while (fgets(line, sizeof(line), fp) && studentCount<MAX_STUDENTS) {
        DashboardStudent *s = &dashboardStudents[studentCount++];
        char *tok = strtok(line, "|"); strcpy(s->roll, tok);
        tok=strtok(NULL, "|"); strcpy(s->name, tok);
        tok=strtok(NULL, "|"); s->correctAnswers=atoi(tok);
        tok=strtok(NULL, "|"); s->totalQuestions=atoi(tok);
        tok=strtok(NULL, "|"); s->flagged=atoi(tok);
        tok=strtok(NULL, "|"); s->totalTime=atoi(tok);
        // parse response times
        for (int i=0; i<s->totalQuestions; ++i) {
            tok = strtok(NULL, ","); s->responseTimes[i]=atoi(tok);
        }
    }
    fclose(fp);
}

/**
 * flagSuspiciousActivity: flags any student with <2s on any question
 */
void flagSuspiciousActivity() {
    for (int i=0;i<studentCount;++i) {
        for (int j=0;j<dashboardStudents[i].totalQuestions;++j) {
            if (dashboardStudents[i].responseTimes[j]<2) {
                dashboardStudents[i].flagged = 1; break;
            }
        }
    }
}

/**
 * rankStudents: simple bubble sort by correctAnswers descending
 */
void rankStudents() {
    for (int i=0;i<studentCount-1;++i)
        for (int j=0;j<studentCount-i-1;++j)
            if (dashboardStudents[j].correctAnswers < dashboardStudents[j+1].correctAnswers) {
                DashboardStudent tmp = dashboardStudents[j];
                dashboardStudents[j] = dashboardStudents[j+1];
                dashboardStudents[j+1] = tmp;
            }
    for (int i=0;i<studentCount;++i) dashboardStudents[i].rank = i+1;
}

/**
 * send_exam_data: transmits rules and a randomized question set to a student socket
 * @client_sock: file descriptor of connected student
 */
void send_exam_data(int client_sock) {
    // Validate and send current rules
    int validTimeout = (answerTimeout>0 && answerTimeout<=3600) ? answerTimeout : 30;
    float validCorrect = (marksForCorrectAnswer>0 && marksForCorrectAnswer<=100) ? marksForCorrectAnswer : 1.0f;
    float validWrong   = (marksDeductedForWrongAnswer>=0 && marksDeductedForWrongAnswer<=100) ? marksDeductedForWrongAnswer : 0.25f;
    int numQ = (totalQuestions < NUM_EXAM_QUESTIONS) ? totalQuestions : NUM_EXAM_QUESTIONS;

    send(client_sock, &validTimeout,  sizeof(int),   0);
    send(client_sock, &validCorrect,  sizeof(float), 0);
    send(client_sock, &validWrong,    sizeof(float), 0);
    send(client_sock, &numQ,          sizeof(int),   0);

    // Shuffle indices for random selection
    int idx[MAX_QUESTIONS]; for(int i=0;i<totalQuestions;i++) idx[i]=i;
    srand(time(NULL));
    for(int i=totalQuestions-1;i>0;i--) {
        int j = rand()%(i+1);
        int tmp = idx[i]; idx[i]=idx[j]; idx[j]=tmp;
    }
    // Send each question struct
    for(int i=0;i<numQ;i++) {
        Question *q = &questions[idx[i]];
        send(client_sock, q, sizeof(Question), 0);
    }
}

/**
 * handle_client: thread entry for each student connection
 */
void *handle_client(void *arg) {
    int client_sock = *(int*)arg; free(arg);

    char buf[MAX_LINE]; int n = recv(client_sock, buf, sizeof(buf)-1, 0);
    if (n<=0) { close(client_sock); return NULL; }
    buf[n]='\0';

    // Expect login: roll|password
    char roll[50], pass[50], name[50], regno[50];
    sscanf(buf, "%49[^|]|%49s", roll, pass);
    if (!verify_student(roll, pass, name, regno)) {
        send(client_sock, "INVALID", 8, 0);
        close(client_sock); return NULL;
    }
    // Send back name|regno
    char resp[MAX_LINE]; snprintf(resp, sizeof(resp), "%s|%s", name, regno);
    send(client_sock, resp, strlen(resp)+1, 0);

    // Register for exam start signal
    pthread_mutex_lock(&clients_mutex);
    clients[clientCount].sock = client_sock;
    strcpy(clients[clientCount].roll, roll);
    clientCount++;
    pthread_mutex_unlock(&clients_mutex);

    // Wait until instructor starts exam
    pthread_mutex_lock(&exam_mutex);
    while (!examStarted) pthread_cond_wait(&exam_cond, &exam_mutex);
    pthread_mutex_unlock(&exam_mutex);

    // Send START and exam data
    send(client_sock, "START", 6, 0);
    send_exam_data(client_sock);

    // Receive completed DashboardStudent struct
    DashboardStudent result;
    recv(client_sock, &result, sizeof(result), 0);
    append_result(&result);

    // Cleanup this client
    pthread_mutex_lock(&clients_mutex);
    for (int i=0;i<clientCount;i++) {
        if (clients[i].sock==client_sock) {
            for (int j=i;j<clientCount-1;j++) clients[j]=clients[j+1];
            clientCount--; break;
        }
    }
    pthread_mutex_unlock(&clients_mutex);
    close(client_sock);
    return NULL;
}

/**
 * instructor_menu: interactive CLI for instructor commands
 */
void instructor_menu() {
    int choice;
    do {
        printf("\n1. Set Time Limit\n2. Add Question\n3. Set Marking\n4. View Dashboard\n5. Start Exam\n6. Exit\nChoice: ");
        scanf("%d", &choice);
        clear_input_buffer();
        switch(choice) {
            case 1: set_time_limit(); break;
            case 2: add_question(); load_questions(); break;
            case 3: set_marking_scheme(); break;
            case 4: displayDashboard(); break;
            case 5: start_exam(); break;
        }
    } while (choice!=6);
}

int main() {
    printf("ExamSys Instructor Server\n");
    load_rules();
    load_questions();

    // Authenticate instructor
    char iid[50], pass[50], name[50];
    printf("Instructor ID: "); scanf("%s", iid);
    printf("Password: "); clear_input_buffer(); getPassword(pass, sizeof(pass));
    if (!verify_instructor(iid, pass, name)) {
        printf("Invalid credentials\n"); return 1;
    }
    printf("Welcome %s!\n", name);

    // Setup TCP listener
    int server_sock = socket(AF_INET, SOCK_STREAM, 0);
    int opt=1; setsockopt(server_sock,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
    struct sockaddr_in addr = {AF_INET, htons(SERVER_PORT), INADDR_ANY};
    bind(server_sock,(struct sockaddr*)&addr,sizeof(addr));
    listen(server_sock,10);

    // Launch instructor CLI thread
    pthread_t it;
    pthread_create(&it,NULL,(void*(*)(void*))instructor_menu,NULL);

    // Accept incoming student connections
    while (1) {
        int *csock = malloc(sizeof(int));
        *csock = accept(server_sock,NULL,NULL);
        pthread_t ct;
        pthread_create(&ct,NULL,handle_client,csock);
        pthread_detach(ct);
    }

    return 0;
}
